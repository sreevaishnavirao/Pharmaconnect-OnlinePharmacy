package com.onlinepharmacy.backend.service;

import com.onlinepharmacy.backend.payload.AnalyticsResponse;

public interface AnalyticsService {
    AnalyticsResponse getAnalyticsData();
}