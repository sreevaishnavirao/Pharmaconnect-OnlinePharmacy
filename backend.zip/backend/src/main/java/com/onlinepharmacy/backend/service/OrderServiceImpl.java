package com.onlinepharmacy.backend.service;

import com.onlinepharmacy.backend.exceptions.APIException;
import com.onlinepharmacy.backend.exceptions.ResourceNotFoundException;
import com.onlinepharmacy.backend.model.*;
import com.onlinepharmacy.backend.payload.OrderDTO;
import com.onlinepharmacy.backend.payload.OrderItemDTO;
import com.onlinepharmacy.backend.repositories.*;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private AddressRepository addressRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private CartItemRepository cartItemRepository; // ✅ NEW (bulk delete)

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private ProductRepository productRepository;

    @Override
    @Transactional
    public OrderDTO placeOrder(
            String emailId,
            Long addressId,
            String paymentMethod,
            String pgName,
            String pgPaymentId,
            String pgStatus,
            String pgResponseMessage
    ) {
        Cart cart = cartRepository.findCartByEmail(emailId);
        if (cart == null) {
            throw new ResourceNotFoundException("Cart", "email", emailId);
        }

        List<CartItem> cartItems = cart.getCartItems();
        if (cartItems == null || cartItems.isEmpty()) {
            throw new APIException("Cart is empty");
        }

        Address address = addressRepository.findById(addressId)
                .orElseThrow(() -> new ResourceNotFoundException("Address", "addressId", addressId));

        // ✅ 1) Save ORDER first
        Order order = new Order();
        order.setEmail(emailId);
        order.setOrderDate(LocalDate.now());
        order.setTotalAmount(cart.getTotalPrice());
        order.setOrderStatus("Order Accepted !");
        order.setAddress(address);

        Order savedOrder = orderRepository.save(order);

        // ✅ 2) Then save PAYMENT linked to savedOrder (prevents transient entity issues)
        Payment payment = new Payment(paymentMethod, pgPaymentId, pgStatus, pgResponseMessage, pgName);
        payment.setOrder(savedOrder);
        Payment savedPayment = paymentRepository.save(payment);

        savedOrder.setPayment(savedPayment);
        savedOrder = orderRepository.save(savedOrder);

        // ✅ 3) Save ORDER ITEMS
        List<OrderItem> orderItems = new ArrayList<>();
        for (CartItem cartItem : cartItems) {
            OrderItem orderItem = new OrderItem();
            orderItem.setProduct(cartItem.getProduct());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setDiscount(cartItem.getDiscount());
            orderItem.setOrderedProductPrice(cartItem.getProductPrice());
            orderItem.setOrder(savedOrder);
            orderItems.add(orderItem);
        }
        orderItems = orderItemRepository.saveAll(orderItems);

        // ✅ 4) Reduce stock (and validate)
        for (CartItem item : cartItems) {
            Product product = item.getProduct();
            int qty = item.getQuantity();

            if (product.getQuantity() < qty) {
                throw new APIException("Not enough stock for " + product.getProductName());
            }

            product.setQuantity(product.getQuantity() - qty);
            productRepository.save(product);
        }

        // ✅ 5) Clear cart safely (no deleting while iterating JPA collection)
        cartItemRepository.deleteAllByCartId(cart.getCartId());
        cart.setTotalPrice(0.0);
        cartRepository.save(cart);

        // ✅ 6) Build DTO
        OrderDTO orderDTO = modelMapper.map(savedOrder, OrderDTO.class);
        orderDTO.setAddressId(addressId);

        if (orderDTO.getOrderItems() == null) {
            orderDTO.setOrderItems(new ArrayList<>());
        }

        for (OrderItem oi : orderItems) {
            orderDTO.getOrderItems().add(modelMapper.map(oi, OrderItemDTO.class));
        }

        return orderDTO;
    }
}
